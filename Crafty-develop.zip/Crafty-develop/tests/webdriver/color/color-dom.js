QUnit.module(module);
require("./color-common.js")(QUnit, browser, "DOM");
